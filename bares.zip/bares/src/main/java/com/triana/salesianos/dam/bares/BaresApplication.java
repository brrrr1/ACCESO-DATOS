package com.triana.salesianos.dam.bares;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaresApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaresApplication.class, args);
	}

}
