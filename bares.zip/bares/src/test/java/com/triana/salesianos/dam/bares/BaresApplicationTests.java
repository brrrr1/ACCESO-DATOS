package com.triana.salesianos.dam.bares;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaresApplicationTests {

	@Test
	void contextLoads() {
	}

}
