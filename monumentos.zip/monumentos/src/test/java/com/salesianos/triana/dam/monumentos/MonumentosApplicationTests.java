package com.salesianos.triana.dam.monumentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonumentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
